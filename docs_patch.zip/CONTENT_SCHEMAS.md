# Schemas
- Theory.md headers required: What it is / Why it matters / Rules of thumb / Mini example / Common mistakes / Mini-glossary / Contrast line (Core only)
- Demos: 2–3 items
- Drills: 12–16 items
- Sequential IDs; unique
- Allowlisted spotKind/targets only
- Rationale <=120 chars
